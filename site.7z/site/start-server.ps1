# Start the backend server for the demo
# Usage: Open PowerShell in project folder and run: .\start-server.ps1

# Stop any existing node processes (best-effort)
Get-Process node -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 1

# Start backend.js using node in a new process
$node = "C:\Program Files\nodejs\node.exe"
if (-Not (Test-Path $node)) {
  $node = "node" # fallback to PATH
}
Start-Process -FilePath $node -ArgumentList "backend.js" -WorkingDirectory (Get-Location).Path
Write-Host "Started backend (if node is installed). Check http://localhost:5000/health"