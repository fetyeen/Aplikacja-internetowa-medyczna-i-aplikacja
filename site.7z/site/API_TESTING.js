// MEDICAL SYSTEM - JAVASCRIPT TESTING & USAGE EXAMPLES
// Skopiuj i wklej w DevTools console (F12) aby testować API

// ===== CONFIGURATION =====
const API_BASE_URL = 'http://localhost:5000/api';
let authToken = localStorage.getItem('token');

// ===== UTILITY FUNCTIONS =====

/**
 * Wrapper dla API requests z automatyczną obsługą błędów
 */
async function apiRequest(endpoint, options = {}) {
  const url = `${API_BASE_URL}${endpoint}`;
  const headers = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  if (authToken) {
    headers['Authorization'] = `Bearer ${authToken}`;
  }

  try {
    const response = await fetch(url, {
      ...options,
      headers,
    });

    const data = await response.json();

    if (!response.ok) {
      console.error(`API Error (${response.status}):`, data);
      throw new Error(data.message || 'API request failed');
    }

    console.log(`✅ ${options.method || 'GET'} ${endpoint}:`, data);
    return data;
  } catch (error) {
    console.error(`❌ Error on ${endpoint}:`, error.message);
    throw error;
  }
}

// ===== AUTHENTICATION =====

/**
 * Rejestracja nowego użytkownika
 */
async function register(name, email, password) {
  const data = await apiRequest('/auth/register', {
    method: 'POST',
    body: JSON.stringify({
      name,
      email,
      password,
      role: 'patient',
    }),
  });
  return data;
}

/**
 * Logowanie użytkownika
 */
async function login(email, password) {
  const data = await apiRequest('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });
  
  if (data.token) {
    authToken = data.token;
    localStorage.setItem('token', authToken);
    console.log('✅ Zalogowano pomyślnie!');
  }
  
  return data;
}

/**
 * Wylogowanie użytkownika
 */
function logout() {
  authToken = null;
  localStorage.removeItem('token');
  console.log('✅ Wylogowano');
}

/**
 * Weryfikacja tokenu JWT
 */
async function verifyToken() {
  const data = await apiRequest('/auth/verify', {
    method: 'POST',
  });
  return data;
}

// ===== PATIENTS MANAGEMENT =====

/**
 * Pobierz wszystkich pacjentów
 */
async function getAllPatients() {
  const data = await apiRequest('/patients');
  return data.patients || [];
}

/**
 * Pobierz szczegóły pacjenta
 */
async function getPatient(patientId) {
  const data = await apiRequest(`/patients/${patientId}`);
  return data.patient;
}

/**
 * Dodaj nowego pacjenta
 */
async function addPatient(patientData) {
  const data = await apiRequest('/patients', {
    method: 'POST',
    body: JSON.stringify(patientData),
  });
  return data.patient;
}

/**
 * Zaktualizuj pacjenta
 */
async function updatePatient(patientId, patientData) {
  const data = await apiRequest(`/patients/${patientId}`, {
    method: 'PUT',
    body: JSON.stringify(patientData),
  });
  return data.patient;
}

/**
 * Usuń pacjenta
 */
async function deletePatient(patientId) {
  await apiRequest(`/patients/${patientId}`, {
    method: 'DELETE',
  });
  console.log(`✅ Pacjent ${patientId} usunięty`);
}

// ===== DOCTORS MANAGEMENT =====

/**
 * Pobierz listę lekarzy
 */
async function getAllDoctors() {
  const data = await apiRequest('/doctors');
  return data.doctors || [];
}

/**
 * Pobierz szczegóły lekarza
 */
async function getDoctor(doctorId) {
  const data = await apiRequest(`/doctors/${doctorId}`);
  return data.doctor;
}

// ===== APPOINTMENTS MANAGEMENT =====

/**
 * Pobierz wszystkie wizyty
 */
async function getAllAppointments() {
  const data = await apiRequest('/appointments');
  return data.appointments || [];
}

/**
 * Pobierz wizyty pacjenta
 */
async function getPatientAppointments(patientId) {
  const data = await apiRequest(`/appointments?patientId=${patientId}`);
  return data.appointments || [];
}

/**
 * Zaplanuj nową wizytę
 */
async function scheduleAppointment(appointmentData) {
  const data = await apiRequest('/appointments', {
    method: 'POST',
    body: JSON.stringify(appointmentData),
  });
  return data.appointment;
}

/**
 * Zaktualizuj wizytę
 */
async function updateAppointment(appointmentId, appointmentData) {
  const data = await apiRequest(`/appointments/${appointmentId}`, {
    method: 'PUT',
    body: JSON.stringify(appointmentData),
  });
  return data.appointment;
}

/**
 * Anuluj wizytę
 */
async function cancelAppointment(appointmentId) {
  await apiRequest(`/appointments/${appointmentId}`, {
    method: 'DELETE',
  });
  console.log(`✅ Wizyta ${appointmentId} anulowana`);
}

// ===== MEDICAL RECORDS =====

/**
 * Pobierz historię medyczną pacjenta
 */
async function getMedicalRecords(patientId) {
  const data = await apiRequest(`/medical-records?patientId=${patientId}`);
  return data.records || [];
}

/**
 * Pobierz szczegóły rekordu medycznego
 */
async function getMedicalRecord(recordId) {
  const data = await apiRequest(`/medical-records/${recordId}`);
  return data.record;
}

/**
 * Dodaj nowy rekord medyczny
 */
async function addMedicalRecord(recordData) {
  const data = await apiRequest('/medical-records', {
    method: 'POST',
    body: JSON.stringify(recordData),
  });
  return data.record;
}

// ===== PRESCRIPTIONS =====

/**
 * Pobierz recepty pacjenta
 */
async function getPrescriptions(patientId) {
  const data = await apiRequest(`/prescriptions?patientId=${patientId}`);
  return data.prescriptions || [];
}

/**
 * Wystawie receptę
 */
async function issuePrescription(prescriptionData) {
  const data = await apiRequest('/prescriptions', {
    method: 'POST',
    body: JSON.stringify(prescriptionData),
  });
  return data.prescription;
}

// ===== INTEGRATION STATUS =====

/**
 * Pobierz status integracji systemów
 */
async function getIntegrationStatus() {
  const data = await apiRequest('/integrations/status');
  return data.integrations || [];
}

/**
 * Pobierz metryki systemu
 */
async function getMetrics() {
  const data = await apiRequest('/integrations/metrics');
  return data.metrics;
}

// ===== SYSTEM HEALTH =====

/**
 * Sprawdź zdrowotność serwera
 */
async function checkHealth() {
  const response = await fetch(`${API_BASE_URL.replace('/api', '')}/health`);
  const data = await response.json();
  console.log('Server health:', data);
  return data;
}

// ============================================
// EXAMPLES - PRAKTYCZNE ZASTOSOWANIA
// ============================================

console.log(`
╔═════════════════════════════════════════════════════════╗
║                                                         ║
║   MEDICAL SYSTEM - API TESTING EXAMPLES                ║
║                                                         ║
║   Skopiuj i wklej poniższe funkcje w DevTools!         ║
║   Naciśnij F12 aby otworzyć konsolę                    ║
║                                                         ║
╚═════════════════════════════════════════════════════════╝
`);

// ===== PRZYKŁAD 1: LOGOWANIE =====
async function exampleLogin() {
  console.log('📝 Logowanie użytkownika...');
  await login('user@example.com', 'password123');
}

// ===== PRZYKŁAD 2: POBIERZ PACJENTÓW =====
async function exampleGetPatients() {
  console.log('👥 Pobieranie listy pacjentów...');
  const patients = await getAllPatients();
  console.table(patients);
}

// ===== PRZYKŁAD 3: DODAJ PACJENTA =====
async function exampleAddPatient() {
  console.log('➕ Dodawanie nowego pacjenta...');
  const newPatient = await addPatient({
    name: 'Karol Testowy',
    email: 'karol.test@example.com',
    phone: '600111222',
    pesel: '00000000001',
    age: 30,
    bloodType: 'O+',
    allergies: [],
    medicalHistory: [],
    currentMedications: [],
  });
  console.table(newPatient);
}

// ===== PRZYKŁAD 4: ZAPLANUJ WIZYTĘ =====
async function exampleScheduleAppointment() {
  console.log('📅 Planowanie wizyty...');
  const appointment = await scheduleAppointment({
    patientId: 'pat-001',
    doctorId: 'doc-001',
    appointmentDate: '2024-02-20',
    appointmentTime: '15:00',
    reason: 'Badanie kontrolne',
    notes: 'Regularna wizyta okresowa',
  });
  console.table(appointment);
}

// ===== PRZYKŁAD 5: POBIERZ WIZYTY PACJENTA =====
async function exampleGetAppointments() {
  console.log('📋 Pobieranie wizyt pacjenta...');
  const appointments = await getPatientAppointments('pat-001');
  console.table(appointments);
}

// ===== PRZYKŁAD 6: DODAJ REKORD MEDYCZNY =====
async function exampleAddMedicalRecord() {
  console.log('📑 Dodawanie rekordu medycznego...');
  const record = await addMedicalRecord({
    patientId: 'pat-001',
    appointmentId: 'apt-001',
    diagnosis: 'Grypa sezonowa',
    symptoms: ['Gorączka', 'Kaszel', 'Ból gardła'],
    treatment: 'Ibuprofen 400mg x 3 dziennie',
    notes: 'Izolacja przez 7 dni',
    tests: ['Szybki test antygenowy'],
    testResults: ['Pozytywny SARS-CoV-2'],
  });
  console.table(record);
}

// ===== PRZYKŁAD 7: WYSTAWIE RECEPTĘ =====
async function exampleIssuePrescription() {
  console.log('💊 Wystawianie recepty...');
  const prescription = await issuePrescription({
    patientId: 'pat-001',
    doctorId: 'doc-001',
    medicationName: 'Ibuprofen',
    dosage: '400mg',
    frequency: 'Co 8 godzin',
    duration: '7 dni',
    instructions: 'Przyjmować ze jedzeniem',
    notes: 'Nie łączyć z alkoholem',
  });
  console.table(prescription);
}

// ===== PRZYKŁAD 8: STATUS INTEGRACJI =====
async function exampleCheckIntegration() {
  console.log('🔗 Sprawdzanie statusu integracji...');
  const status = await getIntegrationStatus();
  console.table(status);
}

// ===== PRZYKŁAD 9: METRYKI SYSTEMU =====
async function exampleGetMetrics() {
  console.log('📊 Pobieranie metryk systemu...');
  const metrics = await getMetrics();
  console.table(metrics);
}

// ===== PRZYKŁAD 10: PEŁNY PRZEPŁYW =====
async function exampleFullWorkflow() {
  try {
    console.log('🚀 Uruchamianie pełnego przepływu...\n');

    // 1. Logowanie
    console.log('1️⃣  Logowanie...');
    await login('user@example.com', 'password123');

    // 2. Pobierz pacjentów
    console.log('\n2️⃣  Pobieranie pacjentów...');
    const patients = await getAllPatients();
    console.log(`Znaleziono ${patients.length} pacjentów`);

    // 3. Pobierz lekarzy
    console.log('\n3️⃣  Pobieranie lekarzy...');
    const doctors = await getAllDoctors();
    console.log(`Znaleziono ${doctors.length} lekarzy`);

    // 4. Zaplanuj wizytę
    if (patients.length > 0 && doctors.length > 0) {
      console.log('\n4️⃣  Planowanie wizyty...');
      const appointment = await scheduleAppointment({
        patientId: patients[0].id,
        doctorId: doctors[0].id,
        appointmentDate: '2024-02-25',
        appointmentTime: '10:00',
        reason: 'Konsultacja',
        notes: 'Pierwsza wizyta po rejestacji',
      });
      console.log('Wizyta zaplanowana:', appointment.id);
    }

    // 5. Pobierz metryki
    console.log('\n5️⃣  Pobieranie metryk...');
    const metrics = await getMetrics();
    console.table(metrics);

    console.log('\n✅ Pełny przepływ zakończony pomyślnie!');
  } catch (error) {
    console.error('❌ Błąd w przepływie:', error);
  }
}

// ============================================
// INSTRUKCJE UŻYTKOWNIKA
// ============================================

console.log(`
GOTOWE FUNKCJE DO TESTOWANIA:

🔐 AUTENTYKACJA:
  - exampleLogin() - Zaloguj się w systemie

👥 PACJENCI:
  - exampleGetPatients() - Pobierz listę pacjentów
  - exampleAddPatient() - Dodaj nowego pacjenta

📅 WIZYTY:
  - exampleScheduleAppointment() - Zaplanuj wizytę
  - exampleGetAppointments() - Pobierz wizyty pacjenta

📑 DOKUMENTACJA MEDYCZNA:
  - exampleAddMedicalRecord() - Dodaj rekord medyczny

💊 RECEPTY:
  - exampleIssuePrescription() - Wystawie receptę

🔗 INTEGRACJA:
  - exampleCheckIntegration() - Status integracji
  - exampleGetMetrics() - Metryki systemu

🚀 PEŁNY TEST:
  - exampleFullWorkflow() - Uruchom pełny przepływ

INSTRUKCJE:
1. Upewnij się, że backend jest uruchomiony (npm start)
2. Otwórz DevTools (F12) → Console
3. Skopiuj i wklej jedną z funkcji powyżej
4. Naciśnij Enter aby uruchomić

PRZYKŁAD:
  exampleLogin()
  exampleGetPatients()
  exampleAddPatient()

`);

// Exportuj funkcje dla globalnego dostępu
window.medicalAPI = {
  // Auth
  login,
  logout,
  register,
  verifyToken,

  // Patients
  getAllPatients,
  getPatient,
  addPatient,
  updatePatient,
  deletePatient,

  // Doctors
  getAllDoctors,
  getDoctor,

  // Appointments
  getAllAppointments,
  getPatientAppointments,
  scheduleAppointment,
  updateAppointment,
  cancelAppointment,

  // Medical Records
  getMedicalRecords,
  getMedicalRecord,
  addMedicalRecord,

  // Prescriptions
  getPrescriptions,
  issuePrescription,

  // Integration
  getIntegrationStatus,
  getMetrics,

  // Health
  checkHealth,

  // Examples
  exampleLogin,
  exampleGetPatients,
  exampleAddPatient,
  exampleScheduleAppointment,
  exampleGetAppointments,
  exampleAddMedicalRecord,
  exampleIssuePrescription,
  exampleCheckIntegration,
  exampleGetMetrics,
  exampleFullWorkflow,
};

console.log('✅ API loaded! Use: medicalAPI.exampleLogin()');
