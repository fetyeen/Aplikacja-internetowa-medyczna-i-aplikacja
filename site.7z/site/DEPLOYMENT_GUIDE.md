# DEPLOYMENT GUIDE - Wdrażanie w produkcji

## 🚀 Opcje wdrażania

### 1. Wdrażanie lokalne (Development)
```bash
npm install
npm start
# Dostęp: http://localhost:5000
```

### 2. Docker (Recommended for all environments)
```bash
# Build
docker build -t medical-system:latest .

# Run
docker run -p 5000:5000 medical-system:latest
```

### 3. Docker Compose (Full stack with PostgreSQL, RabbitMQ)
```bash
docker-compose up -d
# Dostęp: http://localhost
# RabbitMQ Management: http://localhost:15672
```

---

## ☁️ Wdrażanie w chmurze

### AWS (Elastic Beanstalk)
```bash
# 1. Zainstaluj EB CLI
pip install awsebcli

# 2. Inicjuj projekt
eb init -p node.js-18 medical-system
eb create medical-system-env

# 3. Deploy
eb deploy

# 4. Otwórz aplikację
eb open
```

### AWS (ECS - Docker)
```bash
# 1. Login do ECR
aws ecr get-login-password | docker login --username AWS --password-stdin [account].dkr.ecr.us-east-1.amazonaws.com

# 2. Tag i push
docker tag medical-system:latest [account].dkr.ecr.us-east-1.amazonaws.com/medical-system:latest
docker push [account].dkr.ecr.us-east-1.amazonaws.com/medical-system:latest

# 3. Utwórz ECS service via AWS Console
```

### Heroku
```bash
# 1. Zaloguj się do Heroku
heroku login

# 2. Utwórz aplikację
heroku create medical-system

# 3. Ustaw zmienne środowiskowe
heroku config:set JWT_SECRET=your-secret
heroku config:set DATABASE_URL=postgresql://...

# 4. Deploy
git push heroku main

# 5. Otwórz aplikację
heroku open
```

### Vercel (Frontend only)
```bash
# 1. Zainstaluj Vercel CLI
npm install -g vercel

# 2. Deploy
vercel

# 3. Konfiguruj zmienne środowiskowe w Vercel Dashboard
```

### DigitalOcean (App Platform)
```bash
# 1. Zaloguj się do DigitalOcean CLI
doctl auth init

# 2. Utwórz aplikację z app.yaml
doctl apps create --spec app.yaml

# 3. Deploy
doctl apps update [APP_ID] --spec app.yaml
```

### Render.com
```bash
# 1. Połącz GitHub repository
# 2. Utwórz Web Service
# 3. Ustaw build command: npm install
# 4. Ustaw start command: npm start
# 5. Dodaj zmienne środowiskowe
# 6. Deploy
```

### Railway.app
```bash
# 1. Zaloguj się: railway login
# 2. Utwórz projekt: railway init
# 3. Deploy: railway up
# 4. Otwórz: railway open
```

---

## 🔐 Konfiguracja produkcji

### 1. HTTPS/TLS
```bash
# Generuj certyfikat (Let's Encrypt + Certbot)
sudo certbot certonly --standalone -d yourdomain.com

# Lub użyj self-signed (development)
openssl req -x509 -newkey rsa:2048 -keyout key.pem -out cert.pem -days 365
```

### 2. Zmienne środowiskowe
```bash
# .env (production)
NODE_ENV=production
JWT_SECRET=long-random-secret-key-change-in-production
PORT=5000
DB_HOST=your-db-host
DB_PORT=5432
DB_NAME=medical_system
DB_USER=db_user
DB_PASSWORD=strong-password
RABBITMQ_HOST=your-rabbitmq-host
CORS_ORIGIN=https://yourdomain.com
TLS_ENABLED=true
TLS_CERT_PATH=/etc/letsencrypt/live/yourdomain.com/fullchain.pem
TLS_KEY_PATH=/etc/letsencrypt/live/yourdomain.com/privkey.pem
```

### 3. Database Migration
```bash
# Zainstaluj PostgreSQL
sudo apt-get install postgresql postgresql-contrib

# Utwórz bazę danych
createdb medical_system

# Załaduj schema
psql medical_system < schema.sql

# Lub użyj TypeORM/Sequelize do migracji
npm install typeorm pg
npx typeorm migration:run
```

### 4. RabbitMQ Setup
```bash
# Docker
docker run -d --name rabbitmq -p 5672:5672 -p 15672:15672 rabbitmq:3.12-management

# Lub zainstaluj na maszynie
sudo apt-get install rabbitmq-server
sudo systemctl start rabbitmq-server

# Utwórz użytkownika
sudo rabbitmqctl add_user admin password
sudo rabbitmqctl set_permissions -p / admin ".*" ".*" ".*"
```

### 5. SSL/TLS z Nginx
```bash
# Zainstaluj Nginx
sudo apt-get install nginx

# Skopiuj konfigurację
sudo cp nginx.conf /etc/nginx/nginx.conf

# Testuj konfigurację
sudo nginx -t

# Uruchom
sudo systemctl start nginx
sudo systemctl enable nginx
```

---

## 📊 Monitoring & Logging

### PM2 (Process Manager)
```bash
npm install -g pm2

# Start aplikacji
pm2 start backend.js --name medical-system

# Logs
pm2 logs medical-system

# Restart on reboot
pm2 startup
pm2 save
```

### Prometheus + Grafana
```bash
# Docker
docker run -d -p 9090:9090 \
  -v $(pwd)/prometheus.yml:/etc/prometheus/prometheus.yml \
  prom/prometheus

docker run -d -p 3000:3000 grafana/grafana
```

### ELK Stack (Elasticsearch, Logstash, Kibana)
```bash
docker-compose -f docker-compose.elk.yml up -d
# Kibana dostęp: http://localhost:5601
```

---

## 🔄 CI/CD Pipeline

### GitHub Actions (Already configured)
```yaml
# .github/workflows/ci-cd.yml
- Test code
- Build Docker image
- Push to Docker Hub
- Deploy to production (on merge to main)
```

### GitLab CI
```yaml
stages:
  - test
  - build
  - deploy

test:
  stage: test
  script:
    - npm install
    - npm test

build:
  stage: build
  script:
    - docker build -t medical-system:latest .

deploy:
  stage: deploy
  script:
    - docker-compose up -d
```

---

## 📈 Skalowanie

### Horizontal Scaling (Load Balancing)
```bash
# Nginx upstream
upstream backend {
    server app1:5000;
    server app2:5000;
    server app3:5000;
}

# lub Kubernetes
kubectl create deployment medical-system --image=medical-system:latest --replicas=3
```

### Vertical Scaling
- Zwiększ CPU/RAM na maszynie
- Optymalizuj kod
- Użyj caching (Redis)

### Database Scaling
- Read replicas
- Sharding
- Connection pooling (PgBouncer)

---

## 🛡️ Security Checklist

- [ ] Zmień JWT_SECRET
- [ ] Ustaw strong DB password
- [ ] Włącz HTTPS/TLS
- [ ] Skonfiguruj firewall
- [ ] Setup rate limiting
- [ ] Enable CORS properly
- [ ] Regular security updates
- [ ] Backup strategy
- [ ] DDoS protection
- [ ] Web Application Firewall (WAF)

---

## 🔧 Troubleshooting

### Problem: Port already in use
```bash
# Find process using port 5000
lsof -i :5000

# Kill process
kill -9 [PID]
```

### Problem: Database connection failed
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Check credentials in .env
# Test connection
psql -U admin -d medical_system -h localhost
```

### Problem: RabbitMQ not responding
```bash
# Check RabbitMQ status
sudo systemctl status rabbitmq-server

# Restart
sudo systemctl restart rabbitmq-server

# Check UI: http://localhost:15672
```

### Problem: High CPU usage
```bash
# Profile application
node --prof backend.js
node --prof-process isolate-*.log > profile.txt

# Check for memory leaks
npm install clinic
clinic doctor -- node backend.js
```

---

## 📚 Dokumentacja

- [Node.js Best Practices](https://github.com/goldbergyoni/nodebestpractices)
- [Express Security](https://expressjs.com/en/advanced/best-practice-security.html)
- [PostgreSQL Security](https://www.postgresql.org/docs/current/sql-syntax.html)
- [Docker Security](https://docs.docker.com/engine/security/)
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)

---

## ✅ Checklist wdrożenia

- [ ] Kod przetestowany
- [ ] Dokumentacja aktualna
- [ ] Sekretne zmienne konfiguracyjne ustawione
- [ ] Baza danych utworzona i zmigranowana
- [ ] HTTPS skonfigurowany
- [ ] Backups scheduled
- [ ] Monitoring setup
- [ ] Alerting configured
- [ ] Incident response plan
- [ ] Documentation updated
- [ ] Team trained
- [ ] Go-live approval

---

**Pamiętaj: Security first, scalability second! 🔒**
