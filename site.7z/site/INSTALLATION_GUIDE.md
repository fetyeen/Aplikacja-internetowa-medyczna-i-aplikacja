# MEDICAL SYSTEM INTEGRATION - QUICK START GUIDE

## 📋 Wymagania systemowe
- Node.js 14+ (https://nodejs.org/)
- npm 6+ (instalowany razem z Node.js)
- Przeglądarka internetowa (Chrome, Firefox, Safari, Edge)
- Terminal/PowerShell

## 🚀 Instalacja kroku po kroku

### 1. Instalacja zależności
```bash
npm install
```

### 2. Konfiguracja środowiska
```bash
# Skopiuj plik konfiguracji
cp .env.example .env

# Edytuj .env i wstaw swoje wartości (opcjonalnie)
```

### 3. Uruchomienie serwera
```bash
npm start
```
Serwer powinien się uruchomić na: http://localhost:5000

### 4. Otwarcie aplikacji webowej
W przeglądarce wpisz:
```
http://localhost:5000
```

### 5. Otwarcie aplikacji mobilnej
W przeglądarce mobilnej lub w narzędziach developer (F12 → Device Emulation) wpisz:
```
file:///ścieżka/do/mobile.html
```
lub skopiuj `mobile.html` do katalogu z `index.html` i otwórz.

---

## 👤 Dane testowe do logowania

### Konto użytkownika
- **Email:** user@example.com
- **Hasło:** password123

### Konto administratora
- **Email:** admin@example.com
- **Hasło:** admin123

---

## 📱 Funkcjonalności aplikacji

### WEB (index.html)
- ✅ Logowanie i rejestracja
- ✅ Dashboard z statystykami
- ✅ Zarządzanie pacjentami (CRUD)
- ✅ Planowanie wizyt
- ✅ Historia wizyt i wizyt
- ✅ Dokumentacja medyczna
- ✅ Zarządzanie receptami
- ✅ Status integracji systemów
- ✅ Metryki i monitoring

### MOBILNA (mobile.html)
- ✅ Interfejs zbliżony do natywnej aplikacji
- ✅ Nawigacja dolna (4 karty)
- ✅ Moje wizyty i przypomnienia
- ✅ Historia wizyt
- ✅ Rekordy medyczne
- ✅ Ustawienia profilu
- ✅ Wsparcie dla "notch" i safe area insets
- ✅ Zoptymalizowana dla dotykowego interfejsu

### BACKEND (backend.js)
- ✅ Autentykacja OAuth2/JWT
- ✅ Zarządzanie pacjentami
- ✅ Zarządzanie wizytami
- ✅ Historia wizyt
- ✅ Zarządzanie lekarzami
- ✅ Integracja z systemami CRM
- ✅ Ograniczanie prędkości żądań (rate limiting)
- ✅ Bezpieczne przechowywanie haseł (bcrypt)
- ✅ Walidacja danych (Joi)
- ✅ CORS dla wiele Origins
- ✅ Helmet dla bezpieczeństwa

---

## 🔐 Bezpieczeństwo

### Implementowane miary
1. **JWT (JSON Web Tokens)** - 24-godzinny czas wygaśnięcia
2. **Bcrypt** - Szyfrowanie haseł
3. **Rate Limiting** - Max 100 żądań na 15 minut
4. **CORS** - Skonfigurowane dla lokalnego serwera
5. **Helmet** - Nagłówki HTTP bezpieczeństwa
6. **Walidacja Joi** - Walidacja wszystkich wejść

### Dla produkcji
- Zmień `JWT_SECRET` w `.env`
- Skonfiguruj TLS/HTTPS certyfikaty
- Włącz `TLS_ENABLED` w `.env`
- Użyj bazy danych (PostgreSQL, MongoDB) zamiast pamięci
- Skonfiguruj RabbitMQ dla produkcji
- Ustaw odpowiednie `CORS_ORIGIN` wartości

---

## 🔗 API Endpoints

### Autentykacja
- `POST /api/auth/register` - Rejestracja
- `POST /api/auth/login` - Logowanie
- `POST /api/auth/verify` - Weryfikacja tokenu
- `POST /api/auth/refresh` - Odświeżenie tokenu

### Pacjenci
- `GET /api/patients` - Lista pacjentów
- `POST /api/patients` - Dodaj pacjenta
- `GET /api/patients/:id` - Szczegóły pacjenta
- `PUT /api/patients/:id` - Aktualizuj pacjenta
- `DELETE /api/patients/:id` - Usuń pacjenta

### Wizyty
- `GET /api/appointments` - Lista wizyt
- `POST /api/appointments` - Zaplanuj wizytę
- `GET /api/appointments/:id` - Szczegóły wizyty
- `PUT /api/appointments/:id` - Zaktualizuj wizytę
- `DELETE /api/appointments/:id` - Anuluj wizytę

### Dokumentacja medyczna
- `GET /api/medical-records` - Historia
- `GET /api/medical-records/:id` - Szczegóły
- `POST /api/medical-records` - Dodaj zapis

### Lekarze
- `GET /api/doctors` - Lista lekarzy
- `GET /api/doctors/:id` - Szczegóły lekarza

### Recepty
- `GET /api/prescriptions` - Lista recept
- `POST /api/prescriptions` - Dodaj receptę

### Integracja
- `GET /api/integrations/status` - Status integracji
- `GET /api/integrations/metrics` - Metryki systemu

### Zdrowie systemu
- `GET /api/health` - Status zdrowia serwera

---

## 🆘 Rozwiązywanie problemów

### Problem: Port 5000 jest już zajęty
```bash
# Zmień port w backend.js lub w .env:
PORT=3001
```

### Problem: Błąd "Cannot find module"
```bash
npm install
# Usuń node_modules i package-lock.json, zainstaluj ponownie
```

### Problem: CORS errors w konsoli przeglądarki
- Upewnij się, że backend jest uruchomiony (`npm start`)
- Sprawdź czy URL API w `index.html` jest poprawny
- Zmień API_URL na `http://localhost:5000/api`

### Problem: Nie mogę się zalogować
- Upewnij się że backend jest uruchomiony
- Sprawdź dane testowe: `user@example.com` / `password123`
- Otwarty console (F12) pokaże błędy

---

## 🛠️ Rozwój dalszy

### Aby dodać funkcjonalności:
1. Backend: Edytuj `backend.js` (dodaj nowe routes)
2. Web: Edytuj `index.html` (dodaj nowy HTML i JavaScript)
3. Mobilna: Edytuj `mobile.html` (dodaj nowe screens)

### Aby się podłączyć do rzeczywistej bazy danych:
1. Zainstaluj sterownik: `npm install pg` (PostgreSQL)
2. Zastąp `Map` w `backend.js` zapytaniami do bazy danych
3. Skonfiguruj `DB_*` zmienne w `.env`

### Aby włączyć notyfikacje email:
1. Zainstaluj: `npm install nodemailer`
2. Skonfiguruj zmienne `SMTP_*` w `.env`
3. Dodaj logikę wysyłania email w `backend.js`

---

## 📚 Standardy i Compliance

Aplikacja implementuje:
- ✅ **REST API** - Strukturyzowane żądania HTTP
- ✅ **OAuth2** - Autoryzacja
- ✅ **JWT** - Token-based autentykacja
- ✅ **OData v4** - Filtrowanie i paginacja
- ✅ **OpenAPI 3.0** - Specyfikacja API
- ✅ **AMQP 1.0** - Messaging (OASIS standard)
- ✅ **OWASP Top 10** - Bezpieczeństwo

---

## 📞 Wsparcie

Jeśli napotkasz problemy:
1. Sprawdź dziennik serwera (terminal gdzie uruchomiłeś `npm start`)
2. Otwórz DevTools przeglądarki (F12) i sprawdź konsole
3. Sprawdź wkładkę Network aby zobaczyć żądania API

---

## 📄 Licencja

MIT License - Możesz użyć tego kodu dla swoich projektów.

---

**Aplikacja gotowa do użytku! Powodzenia! 🎉**
