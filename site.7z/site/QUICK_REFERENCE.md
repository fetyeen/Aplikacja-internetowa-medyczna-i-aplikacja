# ⚡ QUICK REFERENCE - Przydatne komendy

## 🚀 Uruchamianie

```bash
# Instalacja zależności
npm install

# Uruchomienie serwera (development)
npm start

# Uruchomienie serwera (z nodemon - auto-reload)
npm run dev

# Sprawdzenie zdrowotności
curl http://localhost:5000/health
```

---

## 🧪 Testowanie API

### cURL (Command Line)
```bash
# Logowanie
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"password123"}'

# Pobierz pacjentów (wymaga tokenu)
curl -X GET http://localhost:5000/api/patients \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"

# Dodaj pacjenta
curl -X POST http://localhost:5000/api/patients \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "name":"John Doe",
    "email":"john@example.com",
    "phone":"123456789",
    "pesel":"12345678901",
    "age":30,
    "bloodType":"O+",
    "allergies":[],
    "medicalHistory":[],
    "currentMedications":[]
  }'
```

### PowerShell
```powershell
# Logowanie
$response = Invoke-WebRequest -Uri "http://localhost:5000/api/auth/login" `
  -Method POST -ContentType "application/json" `
  -Body '{"email":"user@example.com","password":"password123"}'
$token = ($response.Content | ConvertFrom-Json).token

# Pobierz pacjentów
$headers = @{ Authorization = "Bearer $token" }
Invoke-WebRequest -Uri "http://localhost:5000/api/patients" -Headers $headers

# Zaloguj wartość (elegancko)
Invoke-RestMethod -Uri "http://localhost:5000/api/auth/login" `
  -Method POST -ContentType "application/json" `
  -Body '{"email":"user@example.com","password":"password123"}' | ConvertTo-Json
```

### JavaScript Console (F12)
```javascript
// Zaloguj się
const login = await fetch('http://localhost:5000/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email: 'user@example.com', password: 'password123' })
});
const { token } = await login.json();
localStorage.setItem('token', token);

// Pobierz pacjentów
const response = await fetch('http://localhost:5000/api/patients', {
  headers: { 'Authorization': `Bearer ${token}` }
});
console.table(await response.json());

// Lub użyj preload funkcji
exampleFullWorkflow();
exampleGetPatients();
```

---

## 🐳 Docker Komendy

```bash
# Build image
docker build -t medical-system:latest .

# Run container
docker run -p 5000:5000 medical-system:latest

# Run compose (full stack)
docker-compose up -d

# Stop compose
docker-compose down

# View logs
docker-compose logs -f backend

# Rebuild and restart
docker-compose up -d --build

# Clean everything
docker-compose down -v
docker system prune -a
```

---

## 📦 npm Komendy

```bash
# Install all dependencies
npm install

# Install specific package
npm install express cors jsonwebtoken

# Install dev dependency
npm install --save-dev nodemon

# Update all packages
npm update

# Check for vulnerabilities
npm audit

# Fix vulnerabilities
npm audit fix

# Show outdated packages
npm outdated

# Remove unused packages
npm prune
```

---

## 🔐 Security & Testing

```bash
# Check for security vulnerabilities
npm audit

# Fix vulnerabilities automatically
npm audit fix

# Force fix (may break compatibility)
npm audit fix --force

# Run linting (if configured)
npm run lint

# Run tests (if configured)
npm run test

# Generate security report
npm audit --json > audit-report.json
```

---

## 📁 File Operations

```bash
# Create .env from .env.example
cp .env.example .env

# View environment variables
cat .env

# Edit configuration
notepad .env
code .env

# Remove node_modules (clean install)
rm -r node_modules package-lock.json
npm install
```

---

## 🌐 Network & Port Management

```bash
# Check if port is in use
netstat -ano | findstr :5000  # Windows
lsof -i :5000                 # Linux/Mac

# Kill process using port
taskkill /PID 1234 /F         # Windows
kill -9 12345                 # Linux/Mac

# Port forwarding (for testing)
ssh -L 5000:localhost:5000 user@remote-server
```

---

## 🔄 Git Commands

```bash
# Clone repository
git clone https://github.com/username/medical-system.git

# Check status
git status

# Add files
git add .

# Commit changes
git commit -m "feat: Add patient registration"

# Push to remote
git push origin main

# Pull latest changes
git pull origin main

# Create new branch
git checkout -b feature/new-feature

# Switch branch
git checkout main

# View commit history
git log --oneline

# Undo changes
git reset --hard HEAD~1
```

---

## 🔧 Development Tools

```bash
# VS Code Extensions
code --install-extension ms-vscode.rest-client
code --install-extension mongodb.mongodb-vscode
code --install-extension esbenp.prettier-vscode

# Generate UUIDs/IDs
node -e "console.log(require('crypto').randomBytes(16).toString('hex'))"

# Current timestamp
node -e "console.log(new Date().toISOString())"

# Base64 encoding/decoding
node -e "console.log(Buffer.from('hello').toString('base64'))"
node -e "console.log(Buffer.from('aGVsbG8=', 'base64').toString())"
```

---

## 📊 Performance & Monitoring

```bash
# Check Node.js version
node --version
node -v

# Check npm version
npm --version
npm -v

# List global packages
npm -g list

# Check memory usage
node --max-old-space-size=2048 backend.js

# Enable profiling
node --prof backend.js

# Analyze profile
node --prof-process isolate-*.log > profile.txt
```

---

## 🚨 Troubleshooting Commands

```bash
# Clear npm cache
npm cache clean --force

# Reinstall all dependencies
rm -r node_modules package-lock.json
npm install

# Check for broken packages
npm audit

# Reset git to remote
git fetch origin
git reset --hard origin/main

# Remove all Docker containers
docker container prune -f

# Check disk space
du -sh *        # Linux/Mac
dir /S          # Windows

# System health check
npm audit
npm outdated
docker system df
```

---

## 🏗️ Building & Deployment

```bash
# Build for production
npm run build

# Test production build locally
npm install -g serve
serve -s build

# Create distribution archive
tar -czf medical-system.tar.gz --exclude=node_modules .

# Verify deployment
curl https://yourdomain.com/health
curl https://yourdomain.com/api/patients
```

---

## 📈 Scaling & Load Testing

```bash
# Install Apache Bench
apt-get install apache2-utils  # Linux
brew install httpd             # Mac

# Load testing (1000 requests, 100 concurrent)
ab -n 1000 -c 100 http://localhost:5000/health

# Install stress testing tool
npm install -g artillery

# Run load test
artillery quick --count 100 --num 1000 http://localhost:5000/api/patients
```

---

## 🔐 SSL/TLS Certificates

```bash
# Generate self-signed certificate (development)
openssl req -x509 -newkey rsa:2048 \
  -keyout key.pem -out cert.pem \
  -days 365 -nodes

# Check certificate validity
openssl x509 -in cert.pem -text -noout

# Generate CSR for CA (production)
openssl req -new -key key.pem -out csr.pem

# Verify certificate chain
openssl verify -CAfile ca-cert.pem server-cert.pem
```

---

## 📱 Mobile Testing

```bash
# Get local IP for mobile access
ipconfig getifaddr en0         # Mac
hostname -I                    # Linux
ipconfig                       # Windows

# Start server on all interfaces
NODE_ENV=production npm start

# Access from mobile on same network
http://YOUR_IP:5000

# Enable port forwarding
ssh -R 5000:localhost:5000 user@remote-server
```

---

## 📝 Logging & Debugging

```bash
# Verbose logging
DEBUG=* npm start

# Specific module logging
DEBUG=express:* npm start

# Save logs to file
npm start > server.log 2>&1

# View logs in real-time
tail -f server.log

# Search logs
grep "error" server.log
grep -i "patient" server.log

# Clear old logs
find . -name "*.log" -mtime +7 -delete
```

---

## 🎯 Environment Variables

```bash
# Windows PowerShell
$env:NODE_ENV = "production"
$env:JWT_SECRET = "your-secret"
npm start

# Linux/Mac
export NODE_ENV=production
export JWT_SECRET=your-secret
npm start

# .env file
NODE_ENV=production
JWT_SECRET=your-secret
PORT=5000
DB_HOST=localhost
```

---

## 🌐 API Status Codes (Quick Reference)

```
200 OK
201 Created
204 No Content
400 Bad Request
401 Unauthorized
403 Forbidden
404 Not Found
429 Too Many Requests
500 Internal Server Error
502 Bad Gateway
503 Service Unavailable
```

---

## 🔗 Useful URLs

```
Local Development:
  http://localhost:5000          # Web app
  http://localhost:5000/mobile   # Mobile app
  http://localhost:5000/health   # Health check
  http://localhost:5000/api/...  # API endpoints

RabbitMQ (Docker Compose):
  http://localhost:15672         # Management UI (guest/guest)

PostgreSQL (Docker Compose):
  localhost:5432                 # Database port

Redis (Docker Compose):
  localhost:6379                 # Cache port
```

---

## ⌨️ Keyboard Shortcuts

```
VS Code:
  Ctrl+Shift+P   - Command Palette
  Ctrl+/         - Toggle comment
  F12            - Debug/DevTools
  Ctrl+Shift+F   - Find in files
  Alt+Up/Down    - Move line up/down
  Ctrl+Shift+J   - Toggle console

Chrome DevTools:
  F12            - Open DevTools
  Ctrl+Shift+I   - Open Inspector
  Ctrl+Shift+J   - Open Console
  Ctrl+Shift+M   - Toggle device mode
  Ctrl+Shift+N   - New incognito window
```

---

## 📚 External Commands

```bash
# JSON formatting
curl http://localhost:5000/api/patients | jq '.'

# API documentation (Swagger)
npm install -g swagger-ui-express

# Database tools
psql -U admin -d medical_system
mongo medical_system

# File comparison
diff file1.js file2.js
vimdiff file1.js file2.js

# Search in files
grep -r "patient" . --include="*.js"
find . -name "*.js" -type f
```

---

## 🚀 One-Liners

```bash
# Start everything
npm install && npm start

# Clean and reinstall
rm -rf node_modules && npm install && npm start

# Run with environment variables
NODE_ENV=production JWT_SECRET=secret npm start

# Start in background
npm start &

# Monitor application
watch -n 1 'curl http://localhost:5000/health'

# Database backup
pg_dump medical_system > backup.sql

# Restore database
psql medical_system < backup.sql
```

---

## 💡 Pro Tips

```bash
# Use alias for faster commands
alias ns="npm start"
alias ni="npm install"
alias dev="npm run dev"

# Use pm2 for process management
pm2 start backend.js --name medical-system
pm2 logs medical-system

# Use Docker for clean environment
docker run -p 5000:5000 medical-system:latest

# Use tmux for multiple terminals
tmux new-session -d -s dev

# Use screen for background processes
screen -S dev -d -m npm start
```

---

**Pozycja jest dużą referencją! Zapisz sobie dla szybkiego dostępu. 🚀**
