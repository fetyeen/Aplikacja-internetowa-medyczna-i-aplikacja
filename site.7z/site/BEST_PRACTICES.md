# BEST PRACTICES & DEVELOPMENT GUIDELINES

## 🏗️ Architektura

### Single Responsibility Principle
- Backend: Jedna odpowiedzialność - służenie API
- Frontend: Jedna odpowiedzialność - renderowanie UI
- Mobile: Jedna odpowiedzialność - mobilny interfejs

### Clean Code
- Czytelne nazwy zmiennych
- Funkcje <= 20 linii
- Brak magic numbers
- DRY (Don't Repeat Yourself)
- KISS (Keep It Simple, Stupid)

### Modularność
```javascript
// ❌ Złe
app.get('/api/patients', (req, res) => {
  // 200 linii logiki
});

// ✅ Dobre
const patientsController = require('./controllers/patients');
app.get('/api/patients', patientsController.getAll);
```

---

## 🔐 Bezpieczeństwo

### Authentication
- ✅ Zawsze używaj JWT z ekspirością
- ✅ Przechowuj tokeny w secure cookies (nie localStorage dla sensitive data)
- ✅ Refresh tokens co godzinę
- ✅ Invalidate tokeny przy wylogowaniu

### Password Security
- ✅ Minimum 8 znaków
- ✅ Wymuszaj mieszankę (wielkie litery, cyfry, znaki specjalne)
- ✅ Hash z bcrypt (min 10 rounds)
- ✅ Nigdy nie loguj haseł

### Input Validation
```javascript
// ✅ Dobre - validate all inputs
const schema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().min(8).required(),
});

const { error, value } = schema.validate(req.body);
if (error) return res.status(400).json({ error: error.details[0].message });
```

### SQL Injection Prevention
- ✅ Zawsze używaj parameterized queries
- ❌ Nigdy nie concatenate SQL

```javascript
// ❌ Złe
db.query(`SELECT * FROM patients WHERE id = ${req.params.id}`);

// ✅ Dobre
db.query('SELECT * FROM patients WHERE id = $1', [req.params.id]);
```

### CORS Configuration
```javascript
// ✅ Dobre - whitelist specific origins
const cors = require('cors');
app.use(cors({
  origin: ['https://yourdomain.com', 'https://app.yourdomain.com'],
  credentials: true
}));

// ❌ Złe - allow all origins
app.use(cors()); // Too permissive
```

---

## 🎯 Performance

### Database Optimization
- ✅ Index frequently queried columns
- ✅ Use pagination for large result sets
- ✅ Connection pooling
- ✅ Query caching

### API Performance
- ✅ Response compression (gzip)
- ✅ HTTP/2 or HTTP/3
- ✅ CDN for static assets
- ✅ Database query optimization

### Frontend Performance
- ✅ Lazy loading
- ✅ Image optimization
- ✅ Code splitting
- ✅ Minification

```javascript
// ✅ Lazy loading example
const patients = await fetchPatients();
const renderedPatients = patients.slice(0, 20);
// Load more on scroll
```

---

## 📝 Code Examples

### Creating a new endpoint

```javascript
// 1. Controller (controllers/patients.js)
exports.create = async (req, res) => {
  // Validate input
  const { error, value } = validatePatient(req.body);
  if (error) return res.status(400).json({ error: error.message });

  try {
    // Create patient
    const patient = new Patient(value);
    await patient.save();

    // Return success
    res.status(201).json({
      message: 'Patient created successfully',
      patient: patient.toJSON()
    });
  } catch (error) {
    console.error('Error creating patient:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// 2. Routes (routes/patients.js)
const express = require('express');
const router = express.Router();
const patientsController = require('../controllers/patients');
const authMiddleware = require('../middleware/auth');

router.post('/', authMiddleware, patientsController.create);

module.exports = router;

// 3. In backend.js
const patientsRouter = require('./routes/patients');
app.use('/api/patients', patientsRouter);
```

### Adding validation

```javascript
// validation/schemas.js
const Joi = require('joi');

const patientSchema = Joi.object({
  name: Joi.string().min(2).max(100).required(),
  email: Joi.string().email().required(),
  phone: Joi.string().pattern(/^\d{9}$/).required(),
  age: Joi.number().min(0).max(150).required(),
  bloodType: Joi.string().valid('A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-').required()
});

module.exports = { patientSchema };
```

---

## 🐛 Error Handling

### Best Practices
```javascript
// ✅ Good error handling
class AppError extends Error {
  constructor(message, statusCode) {
    super(message);
    this.statusCode = statusCode;
  }
}

// Error middleware
app.use((error, req, res, next) => {
  console.error('Error:', error);
  
  const statusCode = error.statusCode || 500;
  const message = error.message || 'Internal server error';
  
  res.status(statusCode).json({
    error: {
      message,
      statusCode,
      timestamp: new Date().toISOString()
    }
  });
});

// Usage
if (!patient) {
  throw new AppError('Patient not found', 404);
}
```

---

## 📊 Logging

### Structured Logging
```javascript
// ✅ Good - structured logs
const logger = {
  info: (message, metadata = {}) => {
    console.log(JSON.stringify({
      level: 'info',
      message,
      timestamp: new Date().toISOString(),
      ...metadata
    }));
  },
  error: (message, error, metadata = {}) => {
    console.error(JSON.stringify({
      level: 'error',
      message,
      error: error.message,
      stack: error.stack,
      timestamp: new Date().toISOString(),
      ...metadata
    }));
  }
};

logger.info('Patient created', { patientId: 'pat-123', userId: 'usr-456' });
```

---

## ♻️ Code Reuse

### Utility Functions
```javascript
// utils/validators.js
const validateEmail = (email) => {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
};

const validatePhone = (phone) => {
  return /^\d{9}$/.test(phone);
};

module.exports = { validateEmail, validatePhone };

// Usage
const { validateEmail } = require('./utils/validators');
if (!validateEmail(req.body.email)) {
  return res.status(400).json({ error: 'Invalid email' });
}
```

---

## 🧪 Testing

### Unit Tests
```javascript
// tests/validators.test.js
const { validateEmail } = require('../utils/validators');

test('validateEmail - valid email', () => {
  expect(validateEmail('user@example.com')).toBe(true);
});

test('validateEmail - invalid email', () => {
  expect(validateEmail('invalid')).toBe(false);
});
```

### Integration Tests
```javascript
// tests/api.integration.test.js
test('GET /api/patients - returns list', async () => {
  const response = await request(app)
    .get('/api/patients')
    .set('Authorization', `Bearer ${token}`);
  
  expect(response.status).toBe(200);
  expect(response.body.patients).toBeInstanceOf(Array);
});
```

---

## 📱 Mobile Development

### Responsive Design
```css
/* ✅ Good - mobile-first approach */
.container {
  padding: 1rem;
}

@media (min-width: 768px) {
  .container {
    padding: 2rem;
  }
}

/* Touch-friendly sizes */
button {
  min-height: 44px;
  min-width: 44px;
  padding: 0.75rem 1.5rem;
}
```

### Safe Area Support
```css
/* ✅ Support for iPhone notch */
padding-top: max(1rem, env(safe-area-inset-top));
padding-bottom: max(1rem, env(safe-area-inset-bottom));
```

---

## 🔄 Git Workflow

### Commit Messages
```
✅ Good commit messages:
feat: Add patient registration endpoint
fix: Correct JWT token expiration calculation
docs: Update API documentation
style: Format code according to eslint rules
refactor: Extract validation logic to separate module
test: Add unit tests for password validation
chore: Update dependencies

❌ Bad commit messages:
fixed stuff
update
changes
asdf
```

### Branch Naming
```
feature/patient-registration
fix/jwt-token-bug
docs/api-documentation
refactor/database-connection
```

---

## 📚 Documentation

### README should include
- ✅ Project description
- ✅ Installation steps
- ✅ Usage examples
- ✅ API documentation
- ✅ Contributing guidelines
- ✅ License

### Code Comments
```javascript
// ✅ Good - explains WHY
// We need to refresh token because it expires every 24 hours
// and users might have long sessions
const shouldRefreshToken = (issuedAt) => {
  return Date.now() - issuedAt > 12 * 60 * 60 * 1000; // 12 hours
};

// ❌ Bad - states obvious
const token = jwt.sign(data); // Create JWT token
```

---

## 🚀 Deployment Checklist

Before deploying to production:
- [ ] All tests pass
- [ ] Code review completed
- [ ] Security audit done
- [ ] Environment variables set
- [ ] Database migrations ready
- [ ] Backups configured
- [ ] Monitoring enabled
- [ ] Error tracking setup
- [ ] Documentation updated
- [ ] Team notified

---

## 📖 Learning Resources

- [Node.js Best Practices](https://github.com/goldbergyoni/nodebestpractices)
- [Express.js Documentation](https://expressjs.com/)
- [OWASP Security Guidelines](https://owasp.org/)
- [PostgreSQL Best Practices](https://wiki.postgresql.org/wiki/Performance_Optimization)
- [Clean Code JavaScript](https://github.com/ryanmcdermott/clean-code-javascript)

---

## ✅ Podsumowanie

Pamiętaj:
1. **Security First** - Zawsze myśl o bezpieczeństwie
2. **Performance** - Zoptymalizuj krytyczne ścieżki
3. **Readability** - Kod dla ludzi, nie dla maszyn
4. **Testing** - Test early, test often
5. **Documentation** - Dokument to kod
6. **Scalability** - Przygotuj się na wzrost

**Happy Coding! 🎉**
