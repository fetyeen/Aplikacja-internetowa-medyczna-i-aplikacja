require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const Joi = require('joi');

const app = express();
const PORT = process.env.PORT || 5000;

// ============ SECURITY MIDDLEWARE ============
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'", "http://localhost:*", "https:"],
      objectSrc: ["'none'"]
    }
  }
}));
app.use(cors({
  origin: ['http://localhost:3000', 'http://localhost:8080', 'file://', '*'],
  credentials: true
}));

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 100 });
app.use('/api/', limiter);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ============ STATIC FILES ============
const path = require('path');
app.use(express.static(path.join(__dirname)));

// ============ ROOT ROUTE ============
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token provided' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(403).json({ error: 'Invalid or expired token' });
  }
};

// ============ IN-MEMORY DATABASES ============
let users = new Map();

// Initialize with test user (password: password123 hashed)
(async () => {
  const testPassword = await bcrypt.hash('password123', 10);
  users.set('user@example.com', {
    id: 'usr-001',
    email: 'user@example.com',
    password: testPassword,
    firstName: 'Test',
    lastName: 'User',
    role: 'patient',
    patientId: 'pat-001'
  });
  
  const adminPassword = await bcrypt.hash('admin123', 10);
  users.set('admin@example.com', {
    id: 'usr-002',
    email: 'admin@example.com',
    password: adminPassword,
    firstName: 'Admin',
    lastName: 'User',
    role: 'admin'
  });
})();

let patients = new Map([
  ['pat-001', {
    id: 'pat-001',
    firstName: 'Jan',
    lastName: 'Kowalski',
    email: 'jan.kowalski@example.com',
    phone: '+48123456789',
    pesel: '12345678901',
    dateOfBirth: '1990-05-15',
    gender: 'male',
    address: 'ul. Poznańska 100, Warsaw',
    bloodType: 'O+',
    status: 'active',
    createdAt: new Date('2024-01-15')
  }],
  ['pat-002', {
    id: 'pat-002',
    firstName: 'Maria',
    lastName: 'Nowak',
    email: 'maria.nowak@example.com',
    phone: '+48987654321',
    pesel: '98765432109',
    dateOfBirth: '1988-03-20',
    gender: 'female',
    address: 'al. Jerozolimskie 50, Warsaw',
    bloodType: 'A+',
    status: 'active',
    createdAt: new Date('2024-02-10')
  }]
]);

let doctors = new Map([
  ['doc-001', {
    id: 'doc-001',
    firstName: 'Adam',
    lastName: 'Lewandowski',
    email: 'a.lewandowski@medical.com',
    specialization: 'Cardiology',
    licenseNumber: 'LIC-001',
    phone: '+48111222333',
    status: 'active'
  }],
  ['doc-002', {
    id: 'doc-002',
    firstName: 'Anna',
    lastName: 'Żakowska',
    email: 'a.zakowska@medical.com',
    specialization: 'Neurology',
    licenseNumber: 'LIC-002',
    phone: '+48444555666',
    status: 'active'
  }]
]);

let appointments = new Map([
  ['apt-001', {
    id: 'apt-001',
    patientId: 'pat-001',
    doctorId: 'doc-001',
    dateTime: new Date('2024-12-15T10:00:00'),
    duration: 30,
    reason: 'Regular checkup',
    status: 'confirmed',
    notes: ''
  }]
]);

let medicalRecords = new Map([
  ['rec-001', {
    id: 'rec-001',
    patientId: 'pat-001',
    doctorId: 'doc-001',
    date: new Date('2024-11-20'),
    diagnosis: 'Hypertension',
    treatment: 'Lisinopril 10mg daily',
    notes: 'Patient shows improvement',
    attachments: []
  }]
]);

let prescriptions = new Map([
  ['presc-001', {
    id: 'presc-001',
    patientId: 'pat-001',
    doctorId: 'doc-001',
    date: new Date('2024-11-20'),
    medications: [
      { name: 'Lisinopril', dosage: '10mg', frequency: 'daily', duration: '30 days' }
    ],
    status: 'active'
  }]
]);

let integrationEvents = [];

// ============ AUTH ENDPOINTS ============
app.post('/api/auth/register', async (req, res) => {
  try {
    const schema = Joi.object({
      email: Joi.string().email().required(),
      password: Joi.string().min(8).required(),
      firstName: Joi.string().required(),
      lastName: Joi.string().required(),
      phone: Joi.string(),
      role: Joi.string().valid('patient', 'doctor', 'admin')
    });
    const { error, value } = schema.validate(req.body);
    if (error) return res.status(400).json({ error: error.details[0].message });
    if (users.has(value.email)) return res.status(409).json({ error: 'User already exists' });

    const hashedPassword = await bcrypt.hash(value.password, 10);
    const user = {
      id: Date.now().toString(),
      email: value.email,
      firstName: value.firstName,
      lastName: value.lastName,
      phone: value.phone || '',
      role: value.role || 'patient',
      patientId: undefined,
      password: hashedPassword,
      createdAt: new Date()
    };
    // If registering as a patient and there's an existing patient with same email, link them
    if (user.role === 'patient') {
      const found = Array.from(patients.values()).find(p => p.email === user.email);
      if (found) user.patientId = found.id;
      else {
        // create a new patient record and link
        const pid = `pat-${Date.now()}`;
        const patient = { id: pid, firstName: user.firstName, lastName: user.lastName, email: user.email, phone: user.phone || '', status: 'active', createdAt: new Date() };
        patients.set(pid, patient);
        user.patientId = pid;
      }
    }
    users.set(value.email, user);
    res.status(201).json({ message: 'Registration successful', user: { id: user.id, email: user.email, firstName: user.firstName, lastName: user.lastName, role: user.role } });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const schema = Joi.object({
      email: Joi.string().email().required(),
      password: Joi.string().required()
    });
    const { error, value } = schema.validate(req.body);
    if (error) return res.status(400).json({ error: error.details[0].message });

    const user = users.get(value.email);
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });

    const isPasswordValid = await bcrypt.compare(value.password, user.password);
    if (!isPasswordValid) return res.status(401).json({ error: 'Invalid credentials' });

    const token = jwt.sign(
      { id: user.id, email: user.email, firstName: user.firstName, lastName: user.lastName, role: user.role, patientId: user.patientId || null },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '24h' }
    );
    res.json({ message: 'Login successful', token, user: { id: user.id, email: user.email, firstName: user.firstName, lastName: user.lastName, role: user.role } });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/auth/verify', (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ valid: false });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
    res.json({ valid: true, user: decoded });
  } catch (error) {
    res.status(401).json({ valid: false, error: error.message });
  }
});

// ============ PATIENT ENDPOINTS ============
app.get('/api/patients', authMiddleware, (req, res) => {
  // If the requester is a patient, only return their own patient record
  if (req.user.role === 'patient') {
    const pid = req.user.patientId || null;
    if (!pid) return res.status(403).json({ error: 'No linked patient record' });
    const patient = patients.get(pid);
    return res.json({ data: patient ? [patient] : [] });
  }
  const filtered = Array.from(patients.values());
  res.json({ data: filtered });
});

app.get('/api/patients/:id', authMiddleware, (req, res) => {
  // Patients may only fetch their own record
  if (req.user.role === 'patient' && req.params.id !== req.user.patientId) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const patient = patients.get(req.params.id);
  if (!patient) return res.status(404).json({ error: 'Patient not found' });
  res.json(patient);
});

app.post('/api/patients', authMiddleware, (req, res) => {
  const { firstName, lastName, email, phone, pesel, dateOfBirth, gender, address, bloodType } = req.body;
  if (!firstName || !lastName) return res.status(400).json({ error: 'First and last name required' });
  const id = `pat-${Date.now()}`;
  const patient = { id, firstName, lastName, email, phone, pesel, dateOfBirth, gender, address, bloodType, status: 'active', createdAt: new Date() };
  patients.set(id, patient);
  res.status(201).json({ message: 'Patient created', patient });
});

app.put('/api/patients/:id', authMiddleware, (req, res) => {
  const patient = patients.get(req.params.id);
  if (!patient) return res.status(404).json({ error: 'Patient not found' });
  const updated = { ...patient, ...req.body, id: patient.id, createdAt: patient.createdAt };
  patients.set(req.params.id, updated);
  res.json({ message: 'Patient updated', patient: updated });
});

// ============ APPOINTMENT ENDPOINTS ============
app.get('/api/appointments', authMiddleware, (req, res) => {
  // Patients should only see their own appointments
  if (req.user.role === 'patient') {
    const pid = req.user.patientId;
    const filtered = Array.from(appointments.values()).filter(a => a.patientId === pid);
    return res.json({ data: filtered });
  }
  const filtered = Array.from(appointments.values());
  res.json({ data: filtered });
});

app.post('/api/appointments', authMiddleware, (req, res) => {
  const { patientId, doctorId, dateTime, duration, reason } = req.body;
  if (!patientId || !doctorId || !dateTime) return res.status(400).json({ error: 'Missing required fields' });
  // If a patient is creating an appointment, ensure it is for their own patientId
  if (req.user.role === 'patient' && req.user.patientId !== patientId) {
    return res.status(403).json({ error: 'Patients can only create appointments for their own record' });
  }
  const id = `apt-${Date.now()}`;
  const appointment = { id, patientId, doctorId, dateTime: new Date(dateTime), duration: duration || 30, reason, status: 'confirmed', notes: '' };
  appointments.set(id, appointment);
  res.status(201).json({ message: 'Appointment created', appointment });
});

app.put('/api/appointments/:id', authMiddleware, (req, res) => {
  const appointment = appointments.get(req.params.id);
  if (!appointment) return res.status(404).json({ error: 'Appointment not found' });
  // Patients may only update their own appointments
  if (req.user.role === 'patient' && appointment.patientId !== req.user.patientId) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const updated = { ...appointment, ...req.body, id: appointment.id };
  appointments.set(req.params.id, updated);
  res.json({ message: 'Appointment updated', appointment: updated });
});

app.delete('/api/appointments/:id', authMiddleware, (req, res) => {
  const appointment = appointments.get(req.params.id);
  if (!appointment) return res.status(404).json({ error: 'Appointment not found' });
  // Patients may only delete their own appointments
  if (req.user.role === 'patient' && appointment.patientId !== req.user.patientId) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  appointments.delete(req.params.id);
  res.json({ message: 'Appointment deleted' });
});

// ============ MEDICAL RECORDS ENDPOINTS ============
app.get('/api/medical-records', authMiddleware, (req, res) => {
  // Patients should only see their own medical records
  if (req.user.role === 'patient') {
    const pid = req.user.patientId;
    const filtered = Array.from(medicalRecords.values()).filter(r => r.patientId === pid);
    return res.json({ data: filtered });
  }
  const filtered = Array.from(medicalRecords.values());
  res.json({ data: filtered });
});

app.get('/api/medical-records/:patientId', authMiddleware, (req, res) => {
  // Patients can only request their own records
  if (req.user.role === 'patient' && req.params.patientId !== req.user.patientId) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const filtered = Array.from(medicalRecords.values()).filter(r => r.patientId === req.params.patientId);
  res.json({ data: filtered });
});

app.post('/api/medical-records', authMiddleware, (req, res) => {
  const { patientId, doctorId, diagnosis, treatment, notes } = req.body;
  if (!patientId || !diagnosis) return res.status(400).json({ error: 'Missing required fields' });
  // Patients may not create medical records for other patients
  if (req.user.role === 'patient' && req.user.patientId !== patientId) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const id = `rec-${Date.now()}`;
  const record = { id, patientId, doctorId, date: new Date(), diagnosis, treatment, notes, attachments: [] };
  medicalRecords.set(id, record);
  res.status(201).json({ message: 'Medical record created', record });
});

// ============ PRESCRIPTION ENDPOINTS ============
app.get('/api/prescriptions/:patientId', authMiddleware, (req, res) => {
  // Patients may only view their own prescriptions
  if (req.user.role === 'patient' && req.params.patientId !== req.user.patientId) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const filtered = Array.from(prescriptions.values()).filter(p => p.patientId === req.params.patientId);
  res.json({ data: filtered });
});

app.post('/api/prescriptions', authMiddleware, (req, res) => {
  const { patientId, doctorId, medications } = req.body;
  if (!patientId || !medications) return res.status(400).json({ error: 'Missing required fields' });
  // Patients may not create prescriptions for other patients
  if (req.user.role === 'patient' && req.user.patientId !== patientId) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const id = `presc-${Date.now()}`;
  const prescription = { id, patientId, doctorId, date: new Date(), medications, status: 'active' };
  prescriptions.set(id, prescription);
  res.status(201).json({ message: 'Prescription created', prescription });
});

// ============ DOCTOR ENDPOINTS ============
app.get('/api/doctors', authMiddleware, (req, res) => {
  const filtered = Array.from(doctors.values());
  res.json({ data: filtered });
});

app.get('/api/doctors/:id', authMiddleware, (req, res) => {
  const doctor = doctors.get(req.params.id);
  if (!doctor) return res.status(404).json({ error: 'Doctor not found' });
  res.json(doctor);
});

// ============ INTEGRATION & MONITORING ============
app.get('/api/integrations/status', authMiddleware, (req, res) => {
  res.json({
    medicalSystem: { connected: true, endpoint: '/api/patients', protocol: 'REST+OAuth2', lastSync: new Date() },
    prescriptionSystem: { connected: true, endpoint: '/api/prescriptions', protocol: 'REST+OAuth2', lastSync: new Date() },
    appointmentSystem: { connected: true, endpoint: '/api/appointments', protocol: 'REST+OAuth2', lastSync: new Date() },
    messaging: { broker: 'RabbitMQ', queue: 'medical-events', protocol: 'AMQP', status: 'active' }
  });
});

app.get('/api/integrations/metrics', authMiddleware, (req, res) => {
  res.json({
    uptime: '99.95%',
    totalRequests: 15840,
    successfulRequests: 15681,
    failedRequests: 159,
    averageResponseTime: '42ms',
    patientsCount: patients.size,
    appointmentsCount: appointments.size,
    medicalRecordsCount: medicalRecords.size
  });
});

// ============ HEALTH CHECK ============
app.get('/health', (req, res) => {
  res.json({ status: 'Medical System Backend is running', timestamp: new Date().toISOString() });
});

app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({ error: { message: err.message || 'Internal Server Error', status: err.status || 500 } });
});

app.listen(PORT, () => {
  console.log(`Medical System Backend running on port ${PORT}`);
});

module.exports = app;
