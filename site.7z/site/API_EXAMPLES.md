# API REFERENCE & EXAMPLES

## 📡 Przykłady zapytań API

### 1. Rejestracja nowego użytkownika
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Jan Kowalski",
    "email": "jan@example.com",
    "password": "bezpiecznehaslo123",
    "role": "patient"
  }'
```

**Odpowiedź (200):**
```json
{
  "message": "User registered successfully",
  "user": {
    "id": "usr-12345",
    "name": "Jan Kowalski",
    "email": "jan@example.com",
    "role": "patient"
  }
}
```

---

### 2. Logowanie użytkownika
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "password": "password123"
  }'
```

**Odpowiedź (200):**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "usr-001",
    "name": "John Doe",
    "email": "user@example.com",
    "role": "patient"
  }
}
```

---

### 3. Pobieranie listy pacjentów
```bash
curl -X GET http://localhost:5000/api/patients \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

**Odpowiedź (200):**
```json
{
  "patients": [
    {
      "id": "pat-001",
      "name": "Maria Nowak",
      "email": "maria@example.com",
      "phone": "123456789",
      "pesel": "12345678901",
      "age": 45,
      "bloodType": "O+",
      "allergies": ["Penicillin"],
      "medicalHistory": ["Hypertension"],
      "currentMedications": ["Lisinopril"],
      "createdAt": "2024-01-15T10:30:00Z",
      "updatedAt": "2024-01-20T14:45:00Z"
    },
    {
      "id": "pat-002",
      "name": "Piotr Lewandowski",
      "email": "piotr@example.com",
      "phone": "987654321",
      "pesel": "98765432109",
      "age": 52,
      "bloodType": "A+",
      "allergies": [],
      "medicalHistory": ["Diabetes"],
      "currentMedications": ["Metformin"],
      "createdAt": "2024-01-10T09:15:00Z",
      "updatedAt": "2024-01-19T11:20:00Z"
    }
  ]
}
```

---

### 4. Dodanie nowego pacjenta
```bash
curl -X POST http://localhost:5000/api/patients \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "name": "Anna Kowalczyk",
    "email": "anna@example.com",
    "phone": "555123456",
    "pesel": "55512345678",
    "age": 38,
    "bloodType": "AB-",
    "allergies": ["Latex", "Sulfonamides"],
    "medicalHistory": ["Asthma"],
    "currentMedications": ["Salbutamol"]
  }'
```

**Odpowiedź (201):**
```json
{
  "message": "Patient added successfully",
  "patient": {
    "id": "pat-003",
    "name": "Anna Kowalczyk",
    "email": "anna@example.com",
    "phone": "555123456",
    "pesel": "55512345678",
    "age": 38,
    "bloodType": "AB-",
    "allergies": ["Latex", "Sulfonamides"],
    "medicalHistory": ["Asthma"],
    "currentMedications": ["Salbutamol"],
    "createdAt": "2024-01-21T15:30:00Z"
  }
}
```

---

### 5. Zaplanowanie wizyty
```bash
curl -X POST http://localhost:5000/api/appointments \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "patientId": "pat-001",
    "doctorId": "doc-001",
    "appointmentDate": "2024-02-15",
    "appointmentTime": "14:30",
    "reason": "Regular checkup",
    "notes": "Patient has hypertension, check BP readings"
  }'
```

**Odpowiedź (201):**
```json
{
  "message": "Appointment scheduled successfully",
  "appointment": {
    "id": "apt-002",
    "patientId": "pat-001",
    "patientName": "Maria Nowak",
    "doctorId": "doc-001",
    "doctorName": "Dr. Anna Kowalski",
    "appointmentDate": "2024-02-15",
    "appointmentTime": "14:30",
    "status": "scheduled",
    "reason": "Regular checkup",
    "notes": "Patient has hypertension, check BP readings",
    "createdAt": "2024-01-21T10:00:00Z"
  }
}
```

---

### 6. Pobieranie wizyt pacjenta
```bash
curl -X GET "http://localhost:5000/api/appointments?patientId=pat-001" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

**Odpowiedź (200):**
```json
{
  "appointments": [
    {
      "id": "apt-001",
      "patientId": "pat-001",
      "patientName": "Maria Nowak",
      "doctorId": "doc-001",
      "doctorName": "Dr. Anna Kowalski",
      "appointmentDate": "2024-01-25",
      "appointmentTime": "10:00",
      "status": "completed",
      "reason": "Blood pressure check",
      "notes": "BP: 140/90, needs medication adjustment",
      "createdAt": "2024-01-15T09:30:00Z"
    }
  ]
}
```

---

### 7. Dodanie historii medycznej
```bash
curl -X POST http://localhost:5000/api/medical-records \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "patientId": "pat-001",
    "appointmentId": "apt-001",
    "diagnosis": "Hypertension Stage 2",
    "symptoms": ["High blood pressure", "Headaches"],
    "treatment": "Started Lisinopril 10mg daily",
    "notes": "Patient to monitor BP daily and return for follow-up in 2 weeks",
    "tests": ["Blood pressure measurement", "ECG"],
    "testResults": ["BP 145/92 mmHg", "ECG Normal"]
  }'
```

**Odpowiedź (201):**
```json
{
  "message": "Medical record added successfully",
  "record": {
    "id": "rec-002",
    "patientId": "pat-001",
    "appointmentId": "apt-001",
    "diagnosis": "Hypertension Stage 2",
    "symptoms": ["High blood pressure", "Headaches"],
    "treatment": "Started Lisinopril 10mg daily",
    "notes": "Patient to monitor BP daily and return for follow-up in 2 weeks",
    "tests": ["Blood pressure measurement", "ECG"],
    "testResults": ["BP 145/92 mmHg", "ECG Normal"],
    "createdAt": "2024-01-25T10:45:00Z"
  }
}
```

---

### 8. Wystawienie recepty
```bash
curl -X POST http://localhost:5000/api/prescriptions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "patientId": "pat-001",
    "doctorId": "doc-001",
    "medicationName": "Lisinopril",
    "dosage": "10mg",
    "frequency": "Once daily",
    "duration": "30 days",
    "instructions": "Take in the morning with water",
    "notes": "Monitor blood pressure daily"
  }'
```

**Odpowiedź (201):**
```json
{
  "message": "Prescription created successfully",
  "prescription": {
    "id": "presc-002",
    "patientId": "pat-001",
    "patientName": "Maria Nowak",
    "doctorId": "doc-001",
    "doctorName": "Dr. Anna Kowalski",
    "medicationName": "Lisinopril",
    "dosage": "10mg",
    "frequency": "Once daily",
    "duration": "30 days",
    "instructions": "Take in the morning with water",
    "notes": "Monitor blood pressure daily",
    "status": "active",
    "issuedDate": "2024-01-25T10:45:00Z",
    "expiryDate": "2024-02-25T10:45:00Z"
  }
}
```

---

### 9. Pobieranie statusu integracji
```bash
curl -X GET http://localhost:5000/api/integrations/status \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

**Odpowiedź (200):**
```json
{
  "integrations": [
    {
      "name": "CRM System",
      "status": "connected",
      "lastSyncTime": "2024-01-21T15:30:00Z",
      "syncStatus": "success"
    },
    {
      "name": "Inventory Management",
      "status": "connected",
      "lastSyncTime": "2024-01-21T15:25:00Z",
      "syncStatus": "success"
    },
    {
      "name": "Email Notifications",
      "status": "connected",
      "lastSyncTime": "2024-01-21T14:50:00Z",
      "syncStatus": "success"
    },
    {
      "name": "SMS Alerts",
      "status": "connected",
      "lastSyncTime": "2024-01-21T14:45:00Z",
      "syncStatus": "success"
    }
  ]
}
```

---

### 10. Pobieranie metryk systemu
```bash
curl -X GET http://localhost:5000/api/integrations/metrics \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

**Odpowiedź (200):**
```json
{
  "metrics": {
    "totalPatients": 2,
    "totalAppointments": 1,
    "totalDoctors": 2,
    "totalMedicalRecords": 1,
    "totalPrescriptions": 1,
    "appointmentsThisMonth": 1,
    "appointmentsCompleted": 1,
    "appointmentsCancelled": 0,
    "averageResponseTime": "45ms",
    "systemUptime": "2h 30m",
    "activeUsers": 1
  }
}
```

---

## 🔐 Nagłówki autentykacji

Wszystkie chronione endpoints wymagają następującego nagłówka:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

JWT token uzyskujesz z endpointu `/api/auth/login`.

---

## ✅ Kody odpowiedzi HTTP

| Kod | Znaczenie | Przykład |
|-----|-----------|---------|
| 200 | OK - Sukces | GET /patients |
| 201 | Created - Zasób stworzony | POST /patients |
| 204 | No Content - Brak zawartości | DELETE /patients/:id |
| 400 | Bad Request - Błędne dane | Brakujące pole |
| 401 | Unauthorized - Brak autoryzacji | Brak tokenu JWT |
| 403 | Forbidden - Dostęp zabroniony | Niewystarczające uprawnienia |
| 404 | Not Found - Nie znaleziono | Pacjent o ID nie istnieje |
| 429 | Too Many Requests - Zbyt wiele żądań | Rate limit przekroczony |
| 500 | Server Error - Błąd serwera | Wyjątek w kodzie |

---

## 🔍 Filtrowanie i paginacja (OData v4)

### Filtrowanie
```bash
# Pacjenci o określonym wieku
GET /api/patients?$filter=age eq 45

# Pacjenci o imieniu zawierającym
GET /api/patients?$filter=substringof('Maria', name)

# Wizyty w określonym dniu
GET /api/appointments?$filter=appointmentDate eq '2024-02-15'
```

### Sortowanie
```bash
# Sortuj pacjentów po imieniu (rosnąco)
GET /api/patients?$orderby=name asc

# Sortuj wizyty po dacie (malejąco)
GET /api/appointments?$orderby=appointmentDate desc
```

### Paginacja
```bash
# Pobierz 10 pacjentów
GET /api/patients?$top=10

# Pomiń 5 pacjentów
GET /api/patients?$skip=5

# Combination
GET /api/patients?$skip=10&$top=10
```

---

## 🛠️ Używanie z Postman/Insomnia

1. Zaimportuj zmienną `{{BASE_URL}}` = `http://localhost:5000/api`
2. Zaimportuj zmienną `{{TOKEN}}` z odpowiedzi /auth/login
3. W autentykacji ustaw `Bearer {{TOKEN}}`
4. Testuj endpointy!

---

## 📝 Struktura JWT Token

```
Header:
{
  "alg": "HS256",
  "typ": "JWT"
}

Payload:
{
  "userId": "usr-001",
  "email": "user@example.com",
  "role": "patient",
  "iat": 1705865400,
  "exp": 1705951800
}

Signature:
HMACSHA256(base64UrlEncode(header) + "." + base64UrlEncode(payload), secret)
```

---

## 🚨 Obsługa błędów

### Błąd walidacji (400)
```json
{
  "message": "Validation error",
  "errors": {
    "email": "Invalid email format",
    "age": "Age must be between 0 and 150"
  }
}
```

### Błąd autoryzacji (401)
```json
{
  "message": "Unauthorized - Invalid or expired token"
}
```

### Błąd Rate Limiting (429)
```json
{
  "message": "Too many requests from this IP, please try again later"
}
```

---

## 💾 Struktura bazy danych

### Pacjenci (Patients)
```json
{
  "id": "pat-xxx",
  "name": "string",
  "email": "string",
  "phone": "string",
  "pesel": "string",
  "age": "number",
  "bloodType": "string",
  "allergies": ["string"],
  "medicalHistory": ["string"],
  "currentMedications": ["string"],
  "createdAt": "ISO-8601",
  "updatedAt": "ISO-8601"
}
```

### Lekarze (Doctors)
```json
{
  "id": "doc-xxx",
  "name": "string",
  "email": "string",
  "phone": "string",
  "specialization": "string",
  "licenseNumber": "string",
  "hospitalAffiliation": "string",
  "availableHours": ["string"]
}
```

### Wizyty (Appointments)
```json
{
  "id": "apt-xxx",
  "patientId": "string",
  "doctorId": "string",
  "appointmentDate": "YYYY-MM-DD",
  "appointmentTime": "HH:MM",
  "status": "scheduled|completed|cancelled",
  "reason": "string",
  "notes": "string",
  "createdAt": "ISO-8601"
}
```

---

**Pełna dokumentacja API dostępna w OpenAPI 3.0 specyfikacji w README.md**
